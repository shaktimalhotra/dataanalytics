package a2;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

import org.apache.spark.mllib.evaluation.MulticlassMetrics;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;

public class Instrumentation {

	static void computeMetricsKNN(Dataset<Row> result, Dataset<Row> testDS, String[] ins, String outputPath) { //
		result = result.select("test_id", "prediction");// keep double
		testDS = testDS.select("test_id", "test_label");
		StringBuffer buff = new StringBuffer();

		Dataset<Row> comparisionDS = result.join(testDS, "test_id");

		MulticlassMetrics m = new MulticlassMetrics(comparisionDS.select("test_label", "prediction"));
		buff.append("K/D =" + ins[0] + ins[1]).append("   --   Accuracy=").append(m.accuracy());

		try {
			Files.write(Paths.get("Results.csv"), buff.toString().getBytes(), StandardOpenOption.APPEND);
		} catch (IOException e) {
			// exception handling left as an exercise for the reader
		}
if(outputPath!=null)
		comparisionDS
				.selectExpr("test_id as test_data_row_number", "test_label as True_Label", "Prediction as Prediction")
				.sort("test_data_row_number").write().format("com.databricks.spark.csv").option("header", "true")
				.save(outputPath);

	}
}
