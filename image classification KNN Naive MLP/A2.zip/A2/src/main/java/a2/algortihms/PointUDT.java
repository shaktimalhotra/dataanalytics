package a2.algortihms;

import java.util.stream.Stream;

import org.apache.spark.ml.linalg.Vectors;
import org.apache.spark.sql.catalyst.InternalRow;
import org.apache.spark.sql.catalyst.expressions.GenericInternalRow;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.MetadataBuilder;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.UserDefinedType;
import org.apache.spark.unsafe.types.UTF8String;

@Deprecated
public class PointUDT extends UserDefinedType<Point> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final int ID_INDEX = 0;
	private static final int LABEL_INDEX = 1;
	private static final int FEATURES_INDEX = 2;
	private static final DataType DATA_TYPE;
	static {
		MetadataBuilder metadataBuilder = new MetadataBuilder();
		metadataBuilder.putLong("maxNumber", Long.MAX_VALUE);
		DATA_TYPE = DataTypes.createStructType(new StructField[] {
				DataTypes.createStructField("id", DataTypes.DoubleType, false, metadataBuilder.build()),
				DataTypes.createStructField("label", DataTypes.StringType, false),
				DataTypes.createStructField("features", DataTypes.StringType, false), });
	}

	@Override
	public DataType sqlType() {
		return DATA_TYPE;
	}

	@Override
	public Point deserialize(Object obj) {
		if (!(obj instanceof InternalRow))
			throw new IllegalStateException();
		InternalRow row = (InternalRow) obj;
		Point p = new Point(row.getDouble(ID_INDEX));
		p.setLabel(row.getString(LABEL_INDEX));
		String f = row.getString(FEATURES_INDEX);

		p.setFeatureVector(Vectors.dense(Stream.of(f.split(",")).mapToDouble(Double::parseDouble).toArray()));

		return p;
	}

	@Override
	public InternalRow serialize(Point p) {
		InternalRow row = new GenericInternalRow(3);
		row.setDouble(ID_INDEX, p.getId());
		row.update(LABEL_INDEX, UTF8String.fromString(p.getLabel()));

		row.update(FEATURES_INDEX, UTF8String.fromString(p.getFeaturesVectorAsString()));

		return row;
	}

	@Override
	public Class<Point> userClass() {
		// TODO Auto-generated method stub
		return Point.class;
	}

}
