package a2.algortihms;

import java.io.Serializable;

import java.util.List;
import java.util.stream.Collectors;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.ml.linalg.Vector;
import org.apache.spark.ml.linalg.Vectors;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.SQLUserDefinedType;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import com.google.common.collect.Lists;
import com.google.common.primitives.Doubles;
@Deprecated
@SQLUserDefinedType(udt = PointUDT.class)
public class Point implements Serializable {

	private static final long serialVersionUID = 1L;
	private final double id;
	private String label;
	private Vector featureVector;

	public Point(double id) {
		this.id = id;// auto boxing

	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public Vector getFeatureVector() {
		return featureVector;
	}

	public void setFeatureVector(Vector featureVector) {
		this.featureVector = featureVector;
	}

	public Double getId() {
		return id;
	}

	public String getFeaturesVectorAsString() {
		return Doubles.asList(featureVector.toArray()).stream().map(number -> String.valueOf(number))
				.collect(Collectors.joining(","));
	}

	@Override
	public String toString() {
		return new StringBuilder(String.valueOf(id)).append(",").append(label).append(",[")
				.append(getFeaturesVectorAsString()).append("]").toString();
	}

	public static void main(String[] args) {// for testing 
		//System.setProperty("hadoop.home.dir","\\\\diac.ap.serco.com\\User_Home$\\asyed\\Documents\\inc");
    	
		Logger.getLogger("org").setLevel(Level.ERROR);
		SparkConf conf = new SparkConf().setAppName("PCA EXAMPLE").setMaster("local[1]");

		JavaSparkContext sc = new JavaSparkContext(conf);

		SparkSession spark = SparkSession.builder().appName("Assignment-2").master("local[1]").getOrCreate();
		Point p1 = new Point(1);
		p1.setLabel("L1");
		p1.setFeatureVector(Vectors.dense(new double[] { 1, 2, 3, 4, 5 }));

		Point p2 = new Point(2);
		p2.setLabel("L2");
		p2.setFeatureVector(Vectors.dense(new double[] { 6, 7, 8, 9, 10 }));

		Point p3 = new Point(2);
		p3.setLabel("L3");
		p3.setFeatureVector(Vectors.dense(new double[] { 11, 12, 13, 14, 15 }));

		List<Point> points = Lists.newArrayList(p1, p2, p3);
		JavaRDD<Row> pointsRDD = sc.parallelize(points).map(RowFactory::create);
		StructType schema = new StructType().add("point", new PointUDT(), false);
		Dataset<Row> datasetFromRdd = spark.createDataFrame(pointsRDD, schema);
		datasetFromRdd.show(false);

		scala.collection.immutable.List<StructField> f = schema.toList();
		System.out.println("### Field Size = " + f.size());

		StructField pointBeanField = f.apply(schema.getFieldIndex("point").get());
		DataType dataType = pointBeanField.dataType();
		System.out.println("### pointBean instance of PointUDT= " + dataType.getClass());

		List<Row> rows = datasetFromRdd.collectAsList();
		System.out.println(rows.toString());

	}

}
