package a2;

import java.text.SimpleDateFormat;
import java.util.stream.Stream;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.ml.Pipeline;
import org.apache.spark.ml.PipelineStage;
import org.apache.spark.ml.feature.PCA;
import org.apache.spark.ml.linalg.VectorUDT;
import org.apache.spark.ml.linalg.Vectors;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import a2.algortihms.KNN;
import scala.Tuple2;

public class DriverApp {

	private static final String COMMA_DELIMITER_REGEX = ",(?=([^\"]*\"[^\"]*\")*[^\"]*$)";// regular expression to

	private static Function<Tuple2<String, Long>, Row> parse = new Function<Tuple2<String, Long>, Row>() {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		@Override
		public Row call(Tuple2<String, Long> t) throws Exception {
			String line = t._1;
			Long idx = t._2;
			int pos = line.indexOf(",");
			Object[] vals = new Object[3];
			vals[0] = idx;
			vals[1] = new Double(line.substring(0, pos));
			vals[2] = Vectors
					.dense(Stream.of(line.substring(pos + 1).split(",")).mapToDouble(Double::parseDouble).toArray())
					.compressed();
			return RowFactory.create(vals);
		}
	};

	private static final SimpleDateFormat dateFormatter = new SimpleDateFormat("yy.dd.mm");
	private static Logger log = Logger.getLogger(DriverApp.class);

	// initializing default
	private static String trainFile = "input/Train-label-28x28-trim.csv";
	private static String testFile = "input/Test-label-28x28-trim.csv";
	private static String outputPath = "output";

	// Default values they come from configuration file
	private static int dimention = 80;
	private static int KNearestNeighbours = 60;
	private static String master = "local[*]";

	public static void main(String[] args) throws Exception {
		Logger.getLogger("org").setLevel(Level.ERROR);// reduce noise from spark
		SparkSession spark;
		boolean debug = true;

		if (args.length >= 5) {
			trainFile = args[0];
			testFile = args[1];
			if (!args[2].contains("null"))
				outputPath = args[2];
			else
				outputPath = null;
			;
			dimention = Integer.parseInt(args[3]);
			KNearestNeighbours = Integer.parseInt(args[4]);

			if (args.length == 6) {
				debug = true;
			} else {
				debug = false;
			}
		} else {
			// log.setLevel(Level.INFO);
			// Logger.getLogger("org").setLevel(Level.ERROR);
			// log.info("input parameters not supplied for driver, initializng default");
		}

		if (debug) {
			master = "local[*]";
			log.setLevel(Level.DEBUG);
		} else {
			master = "yarn";
			log.setLevel(Level.INFO);
		}

		SparkConf conf = new SparkConf().setAppName("GROUP-117-8 ## A2-KNN").setMaster(master);
		conf.set("spark.shuffle.file.buffer", "3M");
		// conf.set("spark.local.dir", ".spark");

		spark = SparkSession.builder().config(conf).getOrCreate();
		JavaSparkContext jsc = JavaSparkContext.fromSparkContext(spark.sparkContext());

		// TODO : THOUGHTS reading in parallel ??
		JavaRDD<Row> trainData = jsc.textFile(trainFile, 6).filter(line -> line.indexOf(",") > 0).zipWithIndex()
				.map(parse);
		JavaRDD<Row> testData = jsc.textFile(testFile, 10).filter(line -> line.indexOf(",") > 0).zipWithIndex()
				.map(parse);

		// Read training data & transform using PCA
		StructType schemaTrain = new StructType(
				new StructField[] { new StructField("training_id", DataTypes.LongType, false, Metadata.empty()),
						new StructField("training_label", DataTypes.DoubleType, false, Metadata.empty()),
						new StructField("training_features", new VectorUDT(), false, Metadata.empty()) });

		StructType schemaTest = new StructType(
				new StructField[] { new StructField("test_id", DataTypes.LongType, false, Metadata.empty()),
						new StructField("test_label", DataTypes.DoubleType, false, Metadata.empty()),
						new StructField("test_features", new VectorUDT(), false, Metadata.empty()) });

		Dataset<Row> trainDS = spark.createDataFrame(trainData, schemaTrain);
		Dataset<Row> testDS = spark.createDataFrame(testData, schemaTest);

		PCA pcaTrain = new PCA().setInputCol("training_features").setOutputCol("pcaFeatures").setK(dimention);
		PCA pcaTest = new PCA().setInputCol("test_features").setOutputCol("pcaFeatures").setK(dimention);
		KNN knn = new KNN().setK(KNearestNeighbours);

		// Execute in Pipleine
		Pipeline pipeline = new Pipeline().setStages(new PipelineStage[] { knn });

		trainDS = pcaTrain.fit(trainDS).transform(trainDS);
		testDS = pcaTest.fit(testDS).transform(testDS);
		log.info("KNN ##  PCA transformation completed .. execution may not trigger at this time");

		log.info("KNN ## fitting trainining data then learning labels for for test data. Execution wil trigger.. ");
		Dataset<Row> result = pipeline.fit(trainDS).transform(testDS);

		log.info("KNN Execution completed");
		log.info("KNN ##  Instrumentation called to compile metrics & present them in csv file for this execution");
		// Instrumentation.computeMetrics(result,testDS);

		log.info("KNN Execution completed computing measure and write output");
		
		Instrumentation ins = new Instrumentation();
		Instrumentation.computeMetricsKNN(result, testDS,
				new String[] { Integer.toString(dimention), Integer.toString(KNearestNeighbours) }, outputPath);
		
		spark.stop();
	}

}
