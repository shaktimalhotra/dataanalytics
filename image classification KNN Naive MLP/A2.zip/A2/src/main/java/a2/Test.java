package a2;

import java.text.SimpleDateFormat;
import java.util.stream.Stream;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.ml.feature.PCA;
import org.apache.spark.ml.linalg.VectorUDT;
import org.apache.spark.ml.linalg.Vectors;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import scala.Tuple2;

public class Test {

	private static final String COMMA_DELIMITER_REGEX = ",(?=([^\"]*\"[^\"]*\")*[^\"]*$)";// regular expression to

	private static Function<Tuple2<String, Long>, Row> parse = new Function<Tuple2<String, Long>, Row>() {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		@Override
		public Row call(Tuple2<String, Long> t) throws Exception {
			String line = t._1;
			Long idx = t._2;
			int pos = line.indexOf(",");
			Object[] vals = new Object[3];
			vals[0] = idx;
			vals[1] = new Double(line.substring(0, pos));
			vals[2] = Vectors
					.dense(Stream.of(line.substring(pos + 1).split(",")).mapToDouble(Double::parseDouble).toArray());
			return RowFactory.create(vals);
		}
	};

	private static final SimpleDateFormat dateFormatter = new SimpleDateFormat("yy.dd.mm");
	private static Logger log = Logger.getLogger(DriverApp.class);

	// initializing default
	private static String trainFile = "input/Train-label-28x28-trim.csv";
	private static String testFile = "input/Test-label-28x28-trim.csv";
	private static String outputPath = "~/output";

	// Default values they come from configuration
	private static int dimention = 6;
	private static int KNearestNeighbours = 60;
	private static String master = "local[*]";

	public static void main(String[] args) throws Exception {
		// System.setProperty("hadoop.home.dir", "C:\\Users\\uzair majid\\winutils");
		Logger.getLogger("org").setLevel(Level.ERROR);
		SparkSession spark;
	
		SparkConf conf = new SparkConf().setAppName("Test").setMaster(master);
		JavaSparkContext sc = new JavaSparkContext(conf);
		JavaRDD<Row> trainData = sc.textFile(trainFile).filter(line -> line.indexOf(",") > 0).zipWithIndex().map(parse);

		JavaRDD<Row> testData = sc.textFile(testFile).filter(line -> line.indexOf(",") > 0).zipWithIndex().map(parse);
		// Read training data & transform using PCA
		StructType schemaTrain = new StructType(
				new StructField[] { new StructField("training_id", DataTypes.LongType, false, Metadata.empty()),
						new StructField("training_label", DataTypes.DoubleType, false, Metadata.empty()),
						new StructField("features", new VectorUDT(), false, Metadata.empty()) });

		StructType schemaTest = new StructType(
				new StructField[] { new StructField("test_id", DataTypes.LongType, false, Metadata.empty()),
						new StructField("test_label", DataTypes.DoubleType, false, Metadata.empty()),
						new StructField("features", new VectorUDT(), false, Metadata.empty()) });

		spark = SparkSession.builder().appName("Assignment-2").master(master).getOrCreate();

		Dataset<Row> trainDS = spark.createDataFrame(trainData, schemaTrain);
		Dataset<Row> testDS = spark.createDataFrame(testData, schemaTest);

		PCA pca = new PCA().setInputCol("features").setOutputCol("pcafeatures").setK(dimention);
		trainDS = pca.fit(trainDS).transform(trainDS).withColumnRenamed("pcafeatures", "training_features").select("training_id","training_label","training_features");
		testDS = pca.fit(testDS).transform(testDS).withColumnRenamed("pcafeatures", "test_features").select("test_id","test_features");
		/**********************************************/
		
		//TODO reqwork partition strategy 
		 testDS.repartition(testDS.col("test_id")).cache().show(4); 

		 Dataset<Row> cart =testDS.crossJoin(trainDS);
		cart.explain();
		cart.show(1);
		
	 

		System.out.println("OUTPUT COMPLETED");
		spark.stop();
	}

}
