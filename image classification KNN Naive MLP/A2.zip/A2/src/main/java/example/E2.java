package example;

import java.text.SimpleDateFormat;

import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.ml.linalg.Vector;
import org.apache.spark.ml.linalg.Vectors;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.api.java.UDF1;
import org.apache.spark.sql.api.java.UDF2;
import org.apache.spark.sql.types.DataType;
import org.datanucleus.metadata.ImplementsMetaData;

import a2.DriverApp;
import a2.algortihms.Point;

class E2 {

	private static final SimpleDateFormat dateFormatter = new SimpleDateFormat("yy.dd.mm");
	private static Logger log = Logger.getLogger(DriverApp.class);

	// initializing default
	private static String trainFile = "input/Train-Label-28x28.csv";
	private static String testFile = "input/test.csv";
	private static String outputPath = "output";

	class Parse implements UDF2<Double, String, Point> {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		@Override
		public Point call(Double rowNum, String line) throws Exception {
			// first element is label and rest are features
			int pos = line.indexOf(",");
			String label = line.substring(0, pos);
			String featuresStr = line.substring(pos + 1);
			Vector vector = Vectors.dense(Double.parseDouble(featuresStr)).compressed();

			Point point = new Point(rowNum);
			point.setLabel(label);
			point.setFeatureVector(vector);

			return point;
		}

	}

	public static void main(String[] args) {
		
	}
}