package example;

public class Test {
public static void main(String[] args) {
	String s="label,0,0,1,1";
	System.out.println(s.substring(s.indexOf(",")+1));
}
}
