package mlc3;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.stream.Stream;
import org.apache.spark.ml.classification.MultilayerPerceptronClassificationModel;
import org.apache.spark.ml.classification.MultilayerPerceptronClassifier;
import org.apache.spark.ml.evaluation.MulticlassClassificationEvaluator;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
//import com.example.SparkSession.UtilityForSparkSession;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.ml.Pipeline;
import org.apache.spark.ml.PipelineModel;
import org.apache.spark.ml.PipelineStage;
import org.apache.spark.ml.classification.MultilayerPerceptronClassificationModel;
import org.apache.spark.ml.classification.MultilayerPerceptronClassifier;
import org.apache.spark.ml.evaluation.MulticlassClassificationEvaluator;
import org.apache.spark.ml.feature.PCA;
import org.apache.spark.ml.feature.PCAModel;
import org.apache.spark.ml.linalg.VectorUDT;
import org.apache.spark.ml.linalg.Vectors;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.functions;
import org.apache.spark.sql.api.java.UDF2;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.Metadata;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import a2.algortihms.CalcVectorDistanceUDF;
import a2.algortihms.FindKNearestNeighboursLabelByFrequency;
import a2.algortihms.KNN;
import a2.algortihms.KNNModel;
import scala.Tuple2;

public class MPCassifier {

	private static final String COMMA_DELIMITER_REGEX = ",(?=([^\"]*\"[^\"]*\")*[^\"]*$)";// regular expression to

	private static Function<Tuple2<String, Long>, Row> parse = new Function<Tuple2<String, Long>, Row>() {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		@Override
		public Row call(Tuple2<String, Long> t) throws Exception {
			String line = t._1;
			Long idx = t._2;
			int pos = line.indexOf(",");
			Object[] vals = new Object[3];
			vals[0] = idx;
			vals[1] = new Double(line.substring(0, pos));
			vals[2] = Vectors
					.dense(Stream.of(line.substring(pos + 1).split(",")).mapToDouble(Double::parseDouble).toArray());
			return RowFactory.create(vals);
		}
	};

	private static final SimpleDateFormat dateFormatter = new SimpleDateFormat("yy.dd.mm");
	private static Logger log = Logger.getLogger(MPCassifier.class);

	// initializing default
	private static String trainFile = "/Users/shaktimalhotra/Downloads/comp5349/Train-label-28x28.csv";
	private static String testFile = "/Users/shaktimalhotra/Downloads/comp5349/Test-label-28x28.csv";
	private static String outputPath = "~/output";

	// Default values they come from configuration
	private static int dimention = 80;
	private static int KNearestNeighbours = 8;
	private static String master = "local[*]";

	public static void main(String[] args) throws Exception {

		Logger.getLogger("org").setLevel(Level.ERROR);
		SparkSession spark;
		boolean debug = true;
		// System.setProperty("hadoop.home.dir",
		// "\\\\diac.ap.serco.com\\User_Home$\\asyed\\Documents\\inc");

		if (args.length >= 5) {
			
			trainFile = args[0];
			testFile = args[1];
			outputPath = args[2];
			dimention = Integer.parseInt(args[3]);
			KNearestNeighbours = Integer.parseInt(args[4]);

			if (args.length == 6) {
				debug=true;
			} else {
				debug=false;
			}
		} else {
//			log.setLevel(Level.INFO);
//			Logger.getLogger("org").setLevel(Level.ERROR);
//			log.info("input parameters not supplied for driver, initializng default");
		}
		
		if (!debug) {
			master="yarn";
		}  

		SparkConf conf = new SparkConf().setAppName("PCA EXAMPLE").setMaster(master);
		JavaSparkContext sc = new JavaSparkContext(conf);
		JavaRDD<Row> trainData = sc.textFile(trainFile).filter(line -> line.indexOf(",") > 0).zipWithIndex().map(parse);

		JavaRDD<Row> testData = sc.textFile(testFile).filter(line -> line.indexOf(",") > 0).zipWithIndex().map(parse);
		// Read training data & transform using PCA
		StructType schemaTrain = new StructType(
				new StructField[] { new StructField("training_id", DataTypes.LongType, false, Metadata.empty()),
						new StructField("label", DataTypes.DoubleType, false, Metadata.empty()),
						new StructField("training_features", new VectorUDT(), false, Metadata.empty()) });
		
		StructType schemaTest = new StructType(
				new StructField[] { new StructField("test_id", DataTypes.LongType, false, Metadata.empty()),
						new StructField("label", DataTypes.DoubleType, false, Metadata.empty()),
						new StructField("test_features", new VectorUDT(), false, Metadata.empty()) });
		

		spark = SparkSession.builder().appName("Assignment-2").master(master).getOrCreate();

		Dataset<Row> trainDS = spark.createDataFrame(trainData, schemaTrain);
		Dataset<Row> testDS = spark.createDataFrame(testData, schemaTest);
		
		
		
		PCA pcaTrain= new PCA().setInputCol("training_features").setOutputCol("pcaFeatures").setK(dimention);
		PCA pcaTest= new PCA().setInputCol("test_features").setOutputCol("pcaFeatures").setK(dimention);
		trainDS.show(2);
		testDS.show(2);
//		   Dataset[] splits = trainDS.randomSplit(new double[]{0.6, 0.4}, 1234L);
//		    Dataset train = splits[0];
//		    Dataset test = splits[1];
		    // specify layers for the neural network:
		    // input layer of size 4 (features), two intermediate of size 5 and 4
		    // and output of size 3 (classes)
		    int[] layers = new int[] {55, 5, 4, 20};
		    // create the trainer and set its parameters
		    MultilayerPerceptronClassifier trainer = new MultilayerPerceptronClassifier()
		      .setLayers(layers)
		      .setTol(1E-4)
		      .setBlockSize(128)
		      //.setSeed(1234L)
		      .setFeaturesCol("training_features")
		      //.setLabelCol("training_label")
		      .setMaxIter(100);
		    // train the model
		   // model.setFeaturesCol("training_features");
		    MultilayerPerceptronClassificationModel model = trainer.fit(trainDS);
		   
		    // compute precision on the test set
//		    Dataset result = model.setFeaturesCol("test_features").transform(testDS);
//		    Dataset predictionAndLabels = result.select("prediction", "test_label");
//		    MulticlassClassificationEvaluator evaluator = new MulticlassClassificationEvaluator()
//		      .setMetricName("weightedPrecision");
//		    System.out.println("Precision = " + evaluator.setPredictionCol("label").evaluate(predictionAndLabels));
//		    // $example off$
		    Dataset<Row> result = model.setFeaturesCol("test_features").transform(testDS);
	        Dataset<Row> predictionAndLabels = result.select("prediction", "label");
	        MulticlassClassificationEvaluator evaluator1 = new MulticlassClassificationEvaluator().setMetricName("accuracy");
	        MulticlassClassificationEvaluator evaluator2 = new MulticlassClassificationEvaluator().setMetricName("weightedPrecision");
	        MulticlassClassificationEvaluator evaluator3 = new MulticlassClassificationEvaluator().setMetricName("weightedRecall");
	        MulticlassClassificationEvaluator evaluator4 = new MulticlassClassificationEvaluator().setMetricName("f1");
	        System.out.println("Accuracy = " + evaluator1.evaluate(predictionAndLabels));
	        System.out.println("Precision = " + evaluator2.evaluate(predictionAndLabels));
	        System.out.println("Recall = " + evaluator3.evaluate(predictionAndLabels));
	        System.out.println("F1 = " + evaluator4.evaluate(predictionAndLabels));
		    spark.stop();
	}
}

